Ce datapack a pour but de rétablir l'équilibre entre l'utilisation et l'obtention du diamant dans MC, et la réalité du diamant.

--> toutes les recettes nécessitant du diamant sont supprimées, à l'exception de la table d'enchantement et du juke box
--> la génération des minerais est modifiée :
		--> aucune modification dans les abîmes
		--> les veines dans la roche sont remplacées par des veines de fer et d'or, plus grosses que la normale

Ce datapack fait partie d'un mod-pack personnel, et je conseille de n'utiliser ce datapack uniquement avec le mod-pack, ou au moins la partie qui contient l'acier. Sinon, vous risqueriez de vous retrouver avec de très grandes difficultés entre l'armure en fer et l'armure en diamant, ou netherite. 

Enfin, ce datapack est prévu pour la version 1.21.6 de MC.

---
P1xThalF4lcon